package com.realestate.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit testovi za Validator klasu
 * @author Student
 * @version 1.0
 */
public class ValidatorTest {

    /**
     * Test validacije email adrese sa validnim email-ovima
     */
    @Test
    @DisplayName("Test validacije validnih email adresa")
    public void testValidirajEmailValidni() {

        assertTrue(Validator.validirajEmail("test@example.com"),
                "test@example.com treba da bude validan email");
        assertTrue(Validator.validirajEmail("user.name@domain.co.rs"),
                "user.name@domain.co.rs treba da bude validan email");
        assertTrue(Validator.validirajEmail("test123@gmail.com"),
                "test123@gmail.com treba da bude validan email");
        assertTrue(Validator.validirajEmail("marko@yahoo.com"),
                "marko@yahoo.com treba da bude validan email");
        assertTrue(Validator.validirajEmail("ana.petrovic@uns.ac.rs"),
                "ana.petrovic@uns.ac.rs treba da bude validan email");
    }

    /**
     * Test validacije email adrese sa nevalidnim email-ovima
     */
    @Test
    @DisplayName("Test validacije nevalidnih email adresa")
    public void testValidirajEmailNevalidni() {

        assertFalse(Validator.validirajEmail("invalid-email"),
                "invalid-email ne treba da bude validan email");
        assertFalse(Validator.validirajEmail("test@"),
                "test@ ne treba da bude validan email");
        assertFalse(Validator.validirajEmail("test.com"),
                "test.com ne treba da bude validan email");
        assertFalse(Validator.validirajEmail(""),
                "prazan string ne treba da bude validan email");
        assertFalse(Validator.validirajEmail(null),
                "null ne treba da bude validan email");
    }

    /**
     * Test validacije telefona sa validnim brojevima
     */
    @Test
    @DisplayName("Test validacije validnih brojeva telefona")
    public void testValidirajTelefonValidni() {

        assertTrue(Validator.validirajTelefon("064123456"),
                "064123456 treba da bude validan telefon");
        assertTrue(Validator.validirajTelefon("+381641234567"),
                "+381641234567 treba da bude validan telefon");
        assertTrue(Validator.validirajTelefon("063-123-456"),
                "063-123-456 treba da bude validan telefon");
        assertTrue(Validator.validirajTelefon("011 123 4567"),
                "011 123 4567 treba da bude validan telefon");
        assertTrue(Validator.validirajTelefon("(011) 123-4567"),
                "(011) 123-4567 treba da bude validan telefon");
    }

    /**
     * Test validacije telefona sa nevalidnim brojevima
     */
    @Test
    @DisplayName("Test validacije nevalidnih brojeva telefona")
    public void testValidirajTelefonNevalidni() {

        assertFalse(Validator.validirajTelefon("123"),
                "123 ne treba da bude validan telefon (prekratak)");
        assertFalse(Validator.validirajTelefon("abcd1234"),
                "abcd1234 ne treba da bude validan telefon (sadrži slova)");
        assertFalse(Validator.validirajTelefon(""),
                "prazan string ne treba da bude validan telefon");
        assertFalse(Validator.validirajTelefon(null),
                "null ne treba da bude validan telefon");
        assertFalse(Validator.validirajTelefon("12345678901234567890"),
                "predugačak broj ne treba da bude validan telefon");
    }

}