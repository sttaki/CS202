package com.realestate.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit testovi za Klijent model klasu
 * @author Student
 * @version 1.0
 */
public class KlijentTest {

    /** Test klijent */
    private Klijent klijent;

    /**
     * Setup metoda koja se izvršava pre svakog testa
     */
    @BeforeEach
    public void setUp() {
        klijent = new Klijent("Marko", "Petrović", "064123456", "marko@gmail.com", "Kupac");
    }

    /**
     * Test kreiranja klijenta sa validnim podacima
     */
    @Test
    @DisplayName("Test kreiranja klijenta sa validnim podacima")
    public void testKreiranjeKlijenta() {
        assertNotNull(klijent, "Klijent treba da bude kreiran");
        assertEquals("Marko", klijent.getIme(), "Ime klijenta treba da bude Marko");
        assertEquals("Petrović", klijent.getPrezime(), "Prezime klijenta treba da bude Petrović");
        assertEquals("064123456", klijent.getTelefon(), "Telefon klijenta treba da bude 064123456");
        assertEquals("marko@gmail.com", klijent.getEmail(), "Email klijenta treba da bude marko@gmail.com");
        assertEquals("Kupac", klijent.getTipKlijenta(), "Tip klijenta treba da bude Kupac");
    }



    /**
     * Test kompletnog ažuriranja podataka klijenta
     */
    @Test
    @DisplayName("Test kompletnog ažuriranja podataka klijenta")
    public void testKompletoAzuriranje() {

        klijent.setIme("Nova");
        klijent.setPrezime("Klijent");
        klijent.setTelefon("069111222");
        klijent.setEmail("nova@klijent.com");
        klijent.setTipKlijenta("Prodavac");
        klijent.setId(555);


        assertEquals("Nova", klijent.getIme(), "Ime treba da bude ažurirano");
        assertEquals("Klijent", klijent.getPrezime(), "Prezime treba da bude ažurirano");
        assertEquals("069111222", klijent.getTelefon(), "Telefon treba da bude ažuriran");
        assertEquals("nova@klijent.com", klijent.getEmail(), "Email treba da bude ažuriran");
        assertEquals("Prodavac", klijent.getTipKlijenta(), "Tip klijenta treba da bude ažuriran");
        assertEquals(555, klijent.getId(), "ID treba da bude ažurirano");
    }


}