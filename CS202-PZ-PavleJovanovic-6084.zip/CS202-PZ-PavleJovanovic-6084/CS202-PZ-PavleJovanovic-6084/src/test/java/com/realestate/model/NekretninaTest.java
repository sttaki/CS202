package com.realestate.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit testovi za Nekretnina model klasu
 * @author Student
 * @version 1.0
 */
public class NekretninaTest {

    /** Test nekretnina */
    private Nekretnina nekretnina;

    /**
     * Setup metoda koja se izvršava pre svakog testa
     */
    @BeforeEach
    public void setUp() {
        nekretnina = new Nekretnina("Stan", "Bulevar Nemanjića 1", 50000.0, 1, "Dostupna");
    }

    /**
     * Test kreiranja nekretnine sa validnim podacima
     */
    @Test
    @DisplayName("Test kreiranja nekretnine sa validnim podacima")
    public void testKreiranjeNekretnine() {
        assertNotNull(nekretnina, "Nekretnina treba da bude kreirana");
        assertEquals("Stan", nekretnina.getTip(), "Tip nekretnine treba da bude Stan");
        assertEquals("Bulevar Nemanjića 1", nekretnina.getAdresa(), "Adresa treba da bude Bulevar Nemanjića 1");
        assertEquals(50000.0, nekretnina.getCena(), 0.01, "Cena treba da bude 50000.0");
        assertEquals(1, nekretnina.getAgentId(), "Agent ID treba da bude 1");
        assertEquals("Dostupna", nekretnina.getStatus(), "Status treba da bude Dostupna");
    }





    /**
     * Test menjanja cene nekretnine
     */
    @Test
    @DisplayName("Test menjanja cene nekretnine")
    public void testMenjanjeCene() {

        assertEquals(50000.0, nekretnina.getCena(), 0.01);


        nekretnina.setCena(75000.0);
        assertEquals(75000.0, nekretnina.getCena(), 0.01, "Cena treba da bude promenjena na 75000.0");


        nekretnina.setCena(42500.50);
        assertEquals(42500.50, nekretnina.getCena(), 0.01, "Cena treba da bude 42500.50");


        nekretnina.setCena(0.0);
        assertEquals(0.0, nekretnina.getCena(), 0.01, "Cena može biti postavljena na 0");
    }


}